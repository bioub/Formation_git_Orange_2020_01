To launch the presentation, browse the index.html page with a web browser.

Use the S key to display the speaker notes.

The project uses a modified version of [explain-git-with-d3] (https://github.com/onlywei/explain-git-with-d3) to display a mini shell and DAG animations.
By now, it requires an Internet connection for require.js to load "d3.min.js" (done in main.js). If you find how to remove it, you're welcome!