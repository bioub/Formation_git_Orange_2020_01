Formation GIT
=============

Installation (à faire avant la formation)
-----------------------------------------
* install sur OSX / Linux / Windows
* créer une clé RSA et configurer son compte sur Orange Forge

Historique
----------
* les trois générations

Différences avec SVN
--------------------
* décentralisé
* possibilité de travailler offline

Mise en oeuvre dans orange forge
--------------------------------
* activer le service GIT sur OF
* créer un repo au nom de l'utilisateur sur orange forge dans le projet atelier GIT
* configuration globable

Création d'un repo local
------------------------
* git init
* regarder le contenu du dossier .git et ./git/gitconfig
* créer un fichier
* add
* commit
* modifier le fichier
* refaire un commit
* le DAG
* git gui
* gitk

Travailler avec un repo distant
-------------------------------
* git clone du même repo pour tous les utilisateurs
* créer un fichier à son nom
* add
* commit
* push
* pull ==> expliquer le merge fast-forward ?

Travailler avec les branches
----------------------------
* créer une branche en local / voir dans GITK
* merger la branche dans master
* pusher master
* continuer à travailler sur la branche
* pusher la branche
* merger
* pusher

Résoudre un conflit
-------------------
* modifier le fichier master/conflit.txt créé par le formateur
* commiter
* fetch
* checkout origin/master
* checkout master
* merge origin/master
* résoudre le conflit
* add
* commit
* push

Git stash
---------
* save
* pop

Ajouter un tag
--------------
* ajouter un tag
* pousser le tag

Workflow
--------
* tout le monde commite sur le même repo
* 1 repo d'intégration et des forks
* expliquer les droits lecture / écriture / rewind


--------------------



