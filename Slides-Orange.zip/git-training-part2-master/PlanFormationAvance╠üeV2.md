Formation GIT avancée
=====================

Prérequis : avoir suivi la formation de base

Légende :
    X = fait, à relire, éventuellement compléter avec un TP
    / = commencé, à compléter

X [Pascal]       Git add interactif (add –p) + TP
X [Pascal]       Git blame
X [Pascal]       Différence entre fast-forward et merge
X [Pascal]       Rebaser, pourquoi, comment, quand
X [Pascal]       Rebase onto
X [Pascal]       Rebase interactif + TP
X [Pascal]       Exemples de workflows git
X [David]        Notion de reference
X [Pascal]       Comment faire un undo (git checkout, revert et reset) + clean
X [Pascal]       Notion d'état "HEAD détachée" + TP
X [Pascal]       Cherry pick

X [David]        Le reflog
X [Pascal]       Les hooks

X [David]        Les attributs
X [David]        Git bisect
X [David]        Git svn (dont migration SVN à git)


X [Pascal]       Submodules
·                Lien avec intégration continue
